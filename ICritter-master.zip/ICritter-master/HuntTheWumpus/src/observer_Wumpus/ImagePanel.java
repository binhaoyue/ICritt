package observer_Wumpus;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class ImagePanel extends JPanel
{
	private BufferedImage image;
	private Dimension size;
	private Point pos;
	
	public ImagePanel(String filename, Dimension bounds, Point loc)	{
		// TODO: implement
		super();
		this.setBackground(Color.WHITE);
		
		try {
			image = ImageIO.read(new File(filename));
			size = bounds;
			pos = loc;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void moveImage(int dx, int dy)	{
		// TODO: implement
		pos.x += dx;
		pos.y += dy;
		repaint();
		
	}
	
	@Override
	public void paintComponent(Graphics g) 	{ // called on a repaint
		// TODO: implement
		super.paintComponent(g);
		
		if(image != null){
			g.drawImage(image, pos.x, pos.y, size.width, size.height, null);
		}
		
		
	}
}
