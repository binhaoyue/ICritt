package observer_Wumpus;
 //Binhao Yue
//CSC 335
//Travis Elbert
//9/10/2014
//HuntTheWumpus: a text viewed hunt the wumpus game
  

public class Hunter {

	private static int R;
	private static int C;
	
	//set hunter's location
	public Hunter(int row, int column){
		setR(row);
		setC(column);
	}
	
	//set hunter's row
	public static void setR(int data){
		R = data;
	}
	
	//set hunter's column
	public static void setC(int data){
		C = data;
	}
	
	//get hunter's row
	public static int getR(){
		return R;
	}
	
	//get hunter's column
	public static int getC(){
		return C;
	}
}
