package observer_Wumpus;

import java.awt.Graphics;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;

import javax.swing.JPanel;

public class MapPanel {


		private Tile[][] tileset = new Tile[10][10]; //the actual map that holds the objects
		private char[][] overlay = new char[10][10]; //holds 0 for hidden, 1 for visited
		private Tile[][] hunterAt = new Tile[10][10];
		private Random generator = new Random();
		
		public MapPanel() {
			//generate overlay, setting all tiles to "hidden"
			for (int i = 0; i < overlay.length; i++) {
				for (int j = 0; j < overlay[i].length; j++) {
					overlay[i][j] = 'o';
				}
			}
			
			//generate blank tileset
			for (int i = 0; i < overlay.length; i++) {
				for (int j = 0; j < overlay[i].length; j++) {
					Tile empty = new Tile("empty");
					tileset[i][j] = empty;
				}
			}
			
			//generate tileset objects
			generateWumpus();
			generatePit();
			generatePit();
			generatePit();
			if(generator.nextInt(2) == 1) //50% chance to generate 4th pit
				generatePit();
			if(generator.nextInt(2) == 1) //50% chance to generate 5th pit
				generatePit();
			generateHunter();
		}
		
		//Non-random map, for testing purposes
		public MapPanel(int seed) {
			//generate overlay, setting all tiles to "hidden"
			for (int i = 0; i < overlay.length; i++) {
				for (int j = 0; j < overlay[i].length; j++) {
					overlay[i][j] = '0';
				}
			}
			
			//generate blank tileset
			for (int i = 0; i < overlay.length; i++) {
				for (int j = 0; j < overlay[i].length; j++) {
					Tile empty = new Tile("empty");
					tileset[i][j] = empty;
				}
			}
			
			//generate tileset objects
			generator = new Random(seed);
			
			generateWumpus();
			generatePit();
			generatePit();
			generatePit();
			if(generator.nextInt(2) == 1) //50% chance to generate 4th pit
				generatePit();
			if(generator.nextInt(2) == 1) //50% chance to generate 5th pit
				generatePit();
			generateHunter();
		}
		
		public int wraparound(int i) {
			if (i < 0) {
				i = i + 10;
			}
			if (i > 9) {
				i = i - 10;
			}
			return i;
		}
		
		public void generateWumpus() { //generate Wumpus and blood, where applicable
			int r = generator.nextInt(10); //row
			int c = generator.nextInt(10); //column
			Tile wumpus = new Tile("wumpus");
			tileset[r][c] = wumpus;
			
			//Generate all 12 blood tiles (blood will wrap as a warning to the hunter)
			Tile blood1 = new Tile("blood");
			tileset[wraparound(r + 1)][c] = blood1;
			
			Tile blood2 = new Tile("blood");
			tileset[r][wraparound(c + 1)] = blood2;

			Tile blood3 = new Tile("blood");
			tileset[wraparound(r - 1)][c] = blood3;

			Tile blood4 = new Tile("blood");
			tileset[r][wraparound(c - 1)] = blood4;

			Tile blood5 = new Tile("blood");
			tileset[wraparound(r + 2)][c] = blood5;
			
			Tile blood6 = new Tile("blood");
			tileset[r][wraparound(c + 2)] = blood6;

			Tile blood7 = new Tile("blood");
			tileset[wraparound(r - 2)][c] = blood7;
			
			Tile blood8 = new Tile("blood");
			tileset[r][wraparound(c - 2)] = blood8;
			
			Tile blood9 = new Tile("blood");
			tileset[wraparound(r + 1)][wraparound(c + 1)] = blood9;
			
			Tile blood10 = new Tile("blood");
			tileset[wraparound(r - 1)][wraparound(c + 1)] = blood10;
			
			Tile blood11 = new Tile("blood");
			tileset[wraparound(r + 1)][wraparound(c - 1)] = blood11;
			
			Tile blood12 = new Tile("blood");
			tileset[wraparound(r - 1)][wraparound(c - 1)] = blood12;
		}
		
		public void generatePit() { //Generate slime pits, slime, and goop, where applicable
			int r;
			int c;
			do {
				r = generator.nextInt(10); //row
				c = generator.nextInt(10); //column
			} while ((tileset[r][c].getVal() != ' ')); 
			//the slime pits should not be generated on the same tile as the wumpus
			
			Tile pit = new Tile("pit");
			tileset[r][c] = pit;
			
			if(tileset[wraparound(r + 1)][c].getVal() == 'B') {
				Tile goop1 = new Tile("goop");
				tileset[wraparound(r + 1)][c] = goop1;
			} else {
				Tile slime1 = new Tile("slime");
				tileset[wraparound(r + 1)][c] = slime1;
			}
			
			if(tileset[r][wraparound(c + 1)].getVal() == 'B') {
				Tile goop2 = new Tile("goop");
				tileset[r][wraparound(c + 1)] = goop2;
			} else {
				Tile slime2 = new Tile("slime");
				tileset[r][wraparound(c + 1)] = slime2;
			}
			
			if(tileset[wraparound(r - 1)][c].getVal() == 'B') {
				Tile goop3 = new Tile("goop");
				tileset[wraparound(r - 1)][c] = goop3;
			} else {
				Tile slime3 = new Tile("slime");
				tileset[wraparound(r - 1)][c] = slime3;
			}

			if(tileset[r][wraparound(c - 1)].getVal() == 'B') {
				Tile goop4 = new Tile("goop");
				tileset[r][wraparound(c - 1)] = goop4;
			} else {
				Tile slime4 = new Tile("slime");
				tileset[r][wraparound(c - 1)] = slime4;
			}
		}
		
		public void generateHunter() {
			int r;
			int c;
			do {
				r = generator.nextInt(10); //row
				c = generator.nextInt(10); //column
			} while ((tileset[r][c].getVal() != ' ') 
					|| (r == 9 || tileset[wraparound(r + 1)][c].getVal() != ' ')
					|| (c == 9 || tileset[r][wraparound(c + 1)].getVal() != ' ')
					|| (r == 0 || tileset[wraparound(r - 1)][c].getVal() != ' ') 
					|| (c == 0 || tileset[r][wraparound(c - 1)].getVal() != ' ')); 
			//the hunter should not be generated on or next to any of the other objects
			//this prevents him from being boxed in at spawn
							
			Hunter hunter = new Hunter(r,c);
			overlay[r][c] = 'O';
		}
		
		//this method returns the fully revealed map diagram
		public String mapFull() {
			String result = "";
			for (int i = 0; i < tileset.length; i++) {
				for (int j = 0; j < tileset[i].length; j++) {
					if (overlay[i][j] == 'O') {
						result += "[O]";
					} else if(tileset[i][j].getVal() == ' ') {
						result += " [    ] ";
					} else {
						result += " [ " + tileset[i][j].getVal() + " ] ";
					}
				}
				result += "\n";
			}
			return result;
		}
		
		//This method sets a tile in the overlay as either hidden (0) or visited (1)
		public void setOverlayTile(int r, int c, char visited) {
			overlay[r][c] = visited;
		}
		
		//this method returns the status (0 for hidden, 1 for visited) of a tile in the overlay
		public char getOverlayTileStatus(int r, int c) {
			return overlay[r][c];
		}
		
		//This returns the actual game map which should be presented to the user
		public String gameMap() {
			String result = "";
			for (int i = 0; i < tileset.length; i++) {
				for (int j = 0; j < tileset[i].length; j++) {
					if(overlay[i][j] == '0') {
						result += " [ X ] ";
					} else if (overlay[i][j] == 'O') {
						result += " [ O ] ";
					} else if(tileset[i][j].getVal() == ' ') {
							result += " [    ] ";
					} else {
						result += " [ " + tileset[i][j].getVal() + " ] ";
					}
				}
				result += "\n";
			}
			return result;
		}


		public Tile[][] getTileset() {
			return tileset;
		}


		public void setTileset(Tile[][] tileset) {
			this.tileset = tileset;
		}
	}
