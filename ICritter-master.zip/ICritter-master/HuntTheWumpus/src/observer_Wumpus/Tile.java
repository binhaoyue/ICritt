package observer_Wumpus;
//Binhao Yue
//CSC 335
//Travis Elbert
//9/10/2014
//HuntTheWumpus: a text viewed hunt the wumpus game

public class Tile {
	private String type;
	private char indicator;
	
	
	//Tile method to show the charactor of given tile type
	public Tile(String tileType) {
		type = tileType;
		
		if (type.equals("wumpus")) {
			indicator = 'W';
		}
		
		if (type.equals("pit")) {
			indicator = 'P';
		}
		
		if (type.equals("slime")) {
			indicator = 'S';
		}
		
		if (type.equals("blood")) {
			indicator = 'B';
		}
		
		if (type.equals("goop")) {
			indicator = 'G';
		}
		
		if (type.equals("empty")) {
			indicator = ' ';
		}
	}
	
	// getVal() method to get the char type
	public char getVal() {
		return indicator;
	}
	
	//toString method to get the String type 
	public String toString(){
		return type;
	}
}
