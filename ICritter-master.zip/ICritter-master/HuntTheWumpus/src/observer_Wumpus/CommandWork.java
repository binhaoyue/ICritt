package observer_Wumpus;
 //Binhao Yue
//CSC 335
//Travis Elbert
//9/10/2014
//HuntTheWumpus: a text viewed hunt the wumpus game


import java.util.Observable;
import java.util.Scanner;
public class CommandWork extends Observable {

	private  String word;
	private MapPanel map;
	static char target = 'N';
	
	public CommandWork(WumpusClient client, MapPanel map) {
		word = "";
		this.map = map;
		this.addObserver(client);
	}
	
	// set command
	public void setCommand(String order) {
		word = order;
	}

	// move method move hunter as command asked
	public void move() {
		if(word.equals("w")){
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), '1'); //reveal where Hunter was
			Hunter.setR(map.wraparound(Hunter.getR()-1));
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), 'O'); //new spot for the Hunter
		}
		else if(word.equals("s")){
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), '1'); 
			Hunter.setR(map.wraparound(Hunter.getR()+1));
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), 'O');
		}
		else if(word.equals("a")){
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), '1');
			Hunter.setC(map.wraparound(Hunter.getC()-1));
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), 'O');
		}
		else if(word.equals("d")){
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), '1');
			Hunter.setC(map.wraparound(Hunter.getC()+1));
			map.setOverlayTile(Hunter.getR(), Hunter.getC(), 'O');
		}
		
		setChanged();
		notifyObservers(map);
	}

	// shoot method shoot the arrow to target
	public  void shoot() {
		String newCommand = word;
		Arrow.setR(Hunter.getR());
		Arrow.setC(Hunter.getC());
			do{
			if(newCommand.equals("w")){
				Arrow.setR(map.wraparound(Arrow.getR()-1));
			}
			else if(newCommand.equals("s")){
				Arrow.setR(map.wraparound(Arrow.getR()+1));
			}
			else if(newCommand.equals("a")){
				Arrow.setC(map.wraparound(Arrow.getC()-1));
			}
			else if(newCommand.equals("d")){
				Arrow.setC(map.wraparound(Arrow.getC()+1));
			}
			char arrowLocation = map.getTileset()[Arrow.getR()][Arrow.getC()].getVal();
			if(arrowLocation == 'W'){
				target = 'W';
				break;
			} 
			
			}	while (Arrow.getR() != Hunter.getR() || Arrow.getC() != Hunter.getC());
			
			if(Arrow.getR() == Hunter.getR() && Arrow.getC() == Hunter.getC()){
				target = 'X';
			}
		setChanged();
		notifyObservers(map);
	}

	// get command as String
	public  String getCommand() {
		return word;
	}
}
