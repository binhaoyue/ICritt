package observer_Wumpus;
 //Binhao Yue
//CSC 335
//Travis Elbert
//9/10/2014
//HuntTheWumpus: a text viewed hunt the wumpus game

public class Arrow {
	
	private static int row; 
	private static int column;

	//set shooting target's row
	public static void setR(int i) {
		row = i;
	}
	
	//set shooting target's column
	public static void setC(int c) {
		column = c;	
	}
	
	//get shooting target's row
	public static int getR(){
		return row;
	}
	
	//get shooting target's row
	public static int getC(){
		return column;
	}
}
