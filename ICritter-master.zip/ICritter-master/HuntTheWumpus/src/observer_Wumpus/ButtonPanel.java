package observer_Wumpus;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicArrowButton;

public class ButtonPanel extends JPanel{
	private ImagePanel buttons; // the panel to control
	private CommandWork commander;
	private BasicArrowButton up, down, left, right, up2, down2, left2, right2; // arrow buttons
	private JLabel Moving = new JLabel();
	private JLabel shooting  = new JLabel();
	
	
	private class ButtonMoveListener implements ActionListener
	{
		public void actionPerformed(ActionEvent arg0) {
			//  Implement
			if(arg0.getSource() ==up){
				commander.setCommand("w");
				commander.move();
			}
			if(arg0.getSource() ==down){
				commander.setCommand("s");
				commander.move();
			}
			if(arg0.getSource() ==left){
				commander.setCommand("a");
				commander.move();
			}
			if(arg0.getSource() ==right){
				commander.setCommand("d");
				commander.move();
			}
			if(arg0.getSource() == up2){
				commander.setCommand("w");
				commander.shoot();
			}
			if(arg0.getSource() == down2){
				commander.setCommand("s");
				commander.shoot();
			}
			if(arg0.getSource() == left2){
				commander.setCommand("a");
				commander.shoot();
			}
			if(arg0.getSource() == right2){
				commander.setCommand("d");
				commander.shoot();
			}
		}
	}
	
	private class ButtonEndListener implements ActionListener
	{
			public void actionPerformed(ActionEvent arg0) {
				//This method intentionally does nothing.
			}
	}
	
	public ButtonPanel(ImagePanel buttons, WumpusClient client) {
		super();
		commander = client.getCommander();
		this.buttons = buttons;
		ActionListener buttonListener = new ButtonMoveListener();
		
		// create actionlistener

		
		this.setLayout(new GridLayout(3, 3)); // grid layout 
		this.setPreferredSize(new Dimension(75, 50)); // set size
		
		
		/* Create the arrow buttons */
		up = new BasicArrowButton(SwingConstants.NORTH);
		down = new BasicArrowButton(SwingConstants.SOUTH);
		left = new BasicArrowButton(SwingConstants.WEST);
		right = new BasicArrowButton(SwingConstants.EAST);
		up2 = new BasicArrowButton(SwingConstants.NORTH);
		down2 = new BasicArrowButton(SwingConstants.SOUTH);
		left2 = new BasicArrowButton(SwingConstants.WEST);
		right2 = new BasicArrowButton(SwingConstants.EAST);
		
		

		
		
		// Add the action listener to each button
		up.addActionListener(buttonListener);
		down.addActionListener(buttonListener);
		left.addActionListener(buttonListener);
		right.addActionListener(buttonListener);
		up2.addActionListener(buttonListener);
		down2.addActionListener(buttonListener);
		left2.addActionListener(buttonListener);
		right2.addActionListener(buttonListener);
		
		// Add each button to this panel (and empty panels)
		add(new JPanel());
		add(Moving);
		Moving.setText("   Moving");
		add (new JPanel());
		add (new JPanel());
		add (new JPanel());
		add(shooting);
		shooting.setText("  Shooting");
		add (new JPanel());
		add (new JPanel());
		this.add(up);
		add (new JPanel());
		add (new JPanel());
		add (new JPanel());
		this.add(up2);
		add (new JPanel());
		this.add(left);
		this.add(down);
		this.add(right);
		add (new JPanel());
		this.add(left2);
		this.add(down2);
		this.add(right2);
	}
	
	public void setEndListeners() {
		ActionListener[] listeners = new ActionListener[8];
		
		listeners[0] = up.getActionListeners()[0];
		listeners[1] = down.getActionListeners()[0];
		listeners[2] = left.getActionListeners()[0];
		listeners[3] = right.getActionListeners()[0];
		listeners[4] = up2.getActionListeners()[0];
		listeners[5] = down2.getActionListeners()[0];
		listeners[6] = left2.getActionListeners()[0];
		listeners[7] = right2.getActionListeners()[0];
		
		up.removeActionListener(listeners[0]);
		down.removeActionListener(listeners[1]);
		left.removeActionListener(listeners[2]);
		right.removeActionListener(listeners[3]);
		up2.removeActionListener(listeners[4]);
		down2.removeActionListener(listeners[5]);
		left2.removeActionListener(listeners[6]);
		right2.removeActionListener(listeners[7]);
		
		ActionListener buttonListener = new ButtonEndListener();
		
		up.addActionListener(buttonListener);
		down.addActionListener(buttonListener);
		left.addActionListener(buttonListener);
		right.addActionListener(buttonListener);
		up2.addActionListener(buttonListener);
		down2.addActionListener(buttonListener);
		left2.addActionListener(buttonListener);
		right2.addActionListener(buttonListener);
	}
}
