package observer_Wumpus;


import java.util.Observable;

public class simpleModel extends Observable{
	
	 private  int counter;

	  public simpleModel() {
	    counter = 0;
	  }

	  public  int currentCount() {
	    return counter;
	  }

	  public void increment() {
	    counter++;

	    this.setChanged();

	    notifyObservers();
	  }

}
