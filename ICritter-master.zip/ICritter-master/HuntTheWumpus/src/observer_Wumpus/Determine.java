package observer_Wumpus;
 //Binhao Yue
//CSC 335
//Travis Elbert
//9/10/2014
//HuntTheWumpus: a text viewed hunt the wumpus game
  

public class Determine {

	private static boolean result;
	private static boolean process = false;
	
	// set the result of game
	public static void setResult(boolean res){
		result = res;
	}
	
	// set if the game should end of not
	public static void setEnd(boolean end){
		process = end;
	}
	
	
	// get the result of game
	public static boolean getResult(){
		if(result == false){
			//System.out.println(MapPanel.mapFull());
			//System.out.println("You Lose!! TT");
		}
		else {
			//System.out.println(MapPanel.mapFull());
			//System.out.println("Win!!!!");
		}
		return result;
	}
	
	
	//get the answer if game should end
	public static boolean getEnd(){
		return process;
	}
}
