package observer_Wumpus;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observable;
import java.util.Observer;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicArrowButton;


public class WumpusClient extends JFrame implements Observer{
	static JTabbedPane current = new JTabbedPane();
	static JTabbedPane textView = new JTabbedPane();
	static JTabbedPane graphicView = new JTabbedPane();

	private CommandWork commander;
	private MapPanel map;
	
	private JTabbedPane panels;
	private JPanel textGame = new JPanel();
	private JTextArea textOutput = new JTextArea();
	private JTextArea message = new JTextArea();
	private JPanel graphicGame = new JPanel();
	private ButtonPanel buttons;
	private ImagePanel hunter;
	
	
	//main method
	public static void main(String[] args) {
		new WumpusClient().setVisible(true);
		
    //System.out.println(gameRunner.map.gameMap());
	}

	
	public WumpusClient() {
		map = new MapPanel();
		commander = new CommandWork(this, map);
		
		layoutThisJFrame();
	}

	public CommandWork getCommander() {
		return commander;
	}
  
	//layoutThisJFrame for layout all elements we need
	public void layoutThisJFrame() {
		setTitle("Hunt the Wumpus");
		setSize(500,500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		buttons = new ButtonPanel(hunter, this);
		JPanel bottom = new JPanel();
		bottom.add(buttons);
		add(buttons,BorderLayout.SOUTH);
    
		textOutput.setEditable(false);
		textOutput.setText(map.gameMap());
		textGame.add(textOutput);
    
		panels = new JTabbedPane();
		panels.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		addLabel(panels, "Graphical View", graphicGame);
	    graphicView = panels;
	    addLabel(panels, "Text View", textGame);
	    textView = panels;
	    add(panels, BorderLayout.NORTH);
	    
	    JPanel messagePanel = new JPanel();
	    messagePanel.setSize(100, 400);
	    message.setEditable(false);
		message.setText("Click a button to begin.");
		messagePanel.add(message);
		add(messagePanel, BorderLayout.CENTER);
	    
	}
	
	  static void addLabel(JTabbedPane Panels, String label, JPanel game) {
		    JButton button = new JButton();
		    button.setBackground(Color.WHITE);
		    Panels.addTab(label, game);
		    current = Panels;
	  }
	  
	  public void updateMessage() {
		  char hunterLocation = map.getTileset()[Hunter.getR()][Hunter.getC()].getVal();
		  
		  if(hunterLocation == 'S'){
			  message.setText("Ew, dirty Slime");
		  }
			
			if(hunterLocation == 'B'){
				message.setText("Look, it's blood!!!");
			}
									
			if(hunterLocation == 'W'){
				message.setText("The Wumpus eats you. CHOMP!");
				buttons.setEndListeners();
				textOutput.setText(map.mapFull());
				textGame.repaint();
			}
									
			if(hunterLocation == 'P'){
				message.setText("Hack! A pit!!");
				buttons.setEndListeners();
				textOutput.setText(map.mapFull());
				textGame.repaint();
			}
									
			if(hunterLocation == 'G'){
				message.setText("Ewww, Goo!");
			}
									
			if(hunterLocation == ' '){
				message.setText("Nothing here!");
			}								
			char arrowLocation = CommandWork.target;

				if(arrowLocation == 'W'){
					message.setText("Nice shot, Buddy!!");
					buttons.setEndListeners();
					textOutput.setText(map.mapFull());
					textGame.repaint();
				}
				
				if(arrowLocation == 'X'){
					message.setText("You missed and shot yourself in the back! It is coming..... ");
					buttons.setEndListeners();
					textOutput.setText(map.mapFull());
					textGame.repaint();
				}

	  }

	  @Override
	  public void update(Observable o, Object arg) {
		  map = (MapPanel) arg;
		  textOutput.setText(map.gameMap());
		  textGame.repaint();
		  updateMessage();
	  }
}